'use client';

import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { PageHeader } from '@/components/layouts/page-header';
import { FadeIn, Stagger, StaggerItem } from '@/components/ui/animate';
import { SafeNumber, SafeDate } from '@/components/safe-format';
import { RefreshCw, TrendingUp, TrendingDown, Wallet, Clock, CheckCircle2, AlertTriangle, FileSpreadsheet } from 'lucide-react';
import { toast } from 'sonner';

export default function DashboardPage() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch('/api/dashboard');
      if (res.ok) setData(await res.json());
    } catch (e: any) { console.error(e); } finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleSync = async () => {
    setSyncing(true);
    try {
      const res = await fetch('/api/sheets/sync', { method: 'POST' });
      const json = await res.json();
      if (res.ok) { toast.success(`Sincronizado: ${json?.sheetsRead ?? 0} abas`); fetchData(); }
      else toast.error(json?.error ?? 'Erro');
    } catch { toast.error('Falha'); } finally { setSyncing(false); }
  };

  const hasData = data && (data?.sheetsRead ?? 0) > 0;

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1200px] mx-auto">
      <FadeIn>
        <PageHeader title="Dashboard Financeiro" description="Visão consolidada das finanças, alimentada pela planilha."
          actions={<Button onClick={handleSync} disabled={syncing} className="gap-2"><RefreshCw className={`h-4 w-4 ${syncing ? 'animate-spin' : ''}`} />Sincronizar</Button>} />
      </FadeIn>
      <FadeIn delay={0.1}>
        <div className="flex flex-wrap gap-3">
          <Badge variant={data?.integrationStatus?.sheets?.connected ? 'default' : 'outline'} className="gap-1 py-1">
            <FileSpreadsheet className="h-3 w-3" />Sheets: {data?.integrationStatus?.sheets?.connected ? 'Conectado' : 'Não conectado'}
          </Badge>
          <Badge variant={data?.integrationStatus?.calendar?.connected ? 'default' : 'outline'} className="gap-1 py-1">
            <Clock className="h-3 w-3" />Calendar: {data?.integrationStatus?.calendar?.connected ? 'Conectado' : 'Não conectado'}
          </Badge>
          {data?.lastSync && <span className="text-xs text-muted-foreground">Última sinc.: <SafeDate date={data.lastSync} options={{ dateStyle: 'short', timeStyle: 'short' }} locale="pt-BR" /></span>}
        </div>
      </FadeIn>
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1,2,3,4].map(i => <Card key={i}><CardContent className="p-6"><div className="h-20 bg-muted animate-pulse rounded" /></CardContent></Card>)}
        </div>
      ) : !hasData ? (
        <FadeIn><Card><CardContent className="p-8 text-center">
          <AlertTriangle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Nenhum dado sincronizado</h3>
          <p className="text-muted-foreground text-sm mb-4">Conecte-se com Google e sincronize a planilha "PLANEJAMENTO JOÃO LUCAS".</p>
          <p className="text-xs text-muted-foreground">Caso não seja encontrada, acesse Configurações para informar o link.</p>
        </CardContent></Card></FadeIn>
      ) : (
        <Stagger staggerDelay={0.08}>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StaggerItem><Card><CardContent className="p-5">
              <div className="flex items-center justify-between mb-3"><span className="text-sm text-muted-foreground">Receitas</span><div className="p-2 rounded-lg bg-primary/10"><TrendingUp className="h-4 w-4 text-primary" /></div></div>
              <p className="text-2xl font-bold font-mono"><SafeNumber value={data?.totalIncome ?? 0} currency="BRL" locale="pt-BR" /></p>
            </CardContent></Card></StaggerItem>
            <StaggerItem><Card><CardContent className="p-5">
              <div className="flex items-center justify-between mb-3"><span className="text-sm text-muted-foreground">Despesas</span><div className="p-2 rounded-lg bg-destructive/10"><TrendingDown className="h-4 w-4 text-destructive" /></div></div>
              <p className="text-2xl font-bold font-mono"><SafeNumber value={data?.totalExpenses ?? 0} currency="BRL" locale="pt-BR" /></p>
            </CardContent></Card></StaggerItem>
            <StaggerItem><Card><CardContent className="p-5">
              <div className="flex items-center justify-between mb-3"><span className="text-sm text-muted-foreground">Saldo</span><div className="p-2 rounded-lg bg-accent/10"><Wallet className="h-4 w-4" /></div></div>
              <p className={`text-2xl font-bold font-mono ${(data?.balance ?? 0) >= 0 ? 'text-primary' : 'text-destructive'}`}><SafeNumber value={data?.balance ?? 0} currency="BRL" locale="pt-BR" /></p>
            </CardContent></Card></StaggerItem>
            <StaggerItem><Card><CardContent className="p-5">
              <div className="flex items-center justify-between mb-3"><span className="text-sm text-muted-foreground">Contas</span><div className="p-2 rounded-lg bg-primary/10"><CheckCircle2 className="h-4 w-4 text-primary" /></div></div>
              <div className="flex gap-4"><div><p className="text-lg font-bold font-mono text-primary">{data?.paidCount ?? 0}</p><p className="text-xs text-muted-foreground">Pagas</p></div><div><p className="text-lg font-bold font-mono text-amber-500">{data?.pendingCount ?? 0}</p><p className="text-xs text-muted-foreground">Pendentes</p></div></div>
            </CardContent></Card></StaggerItem>
          </div>
          <div className="mt-4 text-xs text-muted-foreground bg-muted/50 rounded-lg p-3 flex items-start gap-2">
            <AlertTriangle className="h-3 w-3 mt-0.5 flex-shrink-0" />
            <span>Dados provenientes da planilha sincronizada. Consulte Validação para verificar integridade.</span>
          </div>
        </Stagger>
      )}
    </div>
  );
}
