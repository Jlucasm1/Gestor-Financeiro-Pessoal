'use client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PageHeader } from '@/components/layouts/page-header';
import { FadeIn } from '@/components/ui/animate';
import { BookOpen, Shield, AlertTriangle, FileSpreadsheet, Calendar, Database } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function SobrePage() {
  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1200px] mx-auto">
      <FadeIn><PageHeader title="Sobre / Documentação" description="Arquitetura, modelo de segurança, limitações e próximos passos." /></FadeIn>
      <FadeIn><Card><CardHeader><CardTitle className="flex items-center gap-2 text-base"><BookOpen className="h-4 w-4" />Arquitetura</CardTitle></CardHeader>
      <CardContent className="text-sm space-y-2 text-muted-foreground">
        <p>Sistema web privado de gestão financeira pessoal, integrado ao Google Sheets como fonte de dados (somente leitura).</p>
        <p>Autenticação via Google SSO. Dados financeiros acessíveis apenas após login. Todas as APIs protegidas no servidor.</p>
        <p>Banco de dados para snapshots, validações, configurações e logs de auditoria.</p>
      </CardContent></Card></FadeIn>
      <FadeIn delay={0.1}><Card><CardHeader><CardTitle className="flex items-center gap-2 text-base"><Shield className="h-4 w-4" />Segurança</CardTitle></CardHeader>
      <CardContent className="text-sm space-y-2 text-muted-foreground">
        <p>• Autenticação Google SSO obrigatória</p>
        <p>• Menor privilégio: escopos Google mínimos (Sheets read-only, Calendar read)</p>
        <p>• Tokens manipulados apenas no servidor</p>
        <p>• Logs de auditoria em todas as ações</p>
      </CardContent></Card></FadeIn>
      <FadeIn delay={0.2}><Card><CardHeader><CardTitle className="flex items-center gap-2 text-base"><AlertTriangle className="h-4 w-4" />Limitações Atuais</CardTitle></CardHeader>
      <CardContent className="text-sm space-y-2 text-muted-foreground">
        <p>• <strong>Modo somente leitura</strong>: não altera a planilha (WRITE_ENABLED=false)</p>
        <p>• <strong>Criação de eventos Calendar</strong>: desativada (CALENDAR_WRITE_ENABLED=false)</p>
        <p>• <strong>Fórmulas quebradas</strong>: detectadas 8 referências #REF! em B5:I5 do "Plano de Comissionamento" — não corrigidas, decisão do usuário</p>
        <p>• Integração Google depende do usuário fazer login via Google SSO</p>
      </CardContent></Card></FadeIn>
      <FadeIn delay={0.3}><Card><CardHeader><CardTitle className="flex items-center gap-2 text-base"><Database className="h-4 w-4" />Próximos Passos (Fase 2)</CardTitle></CardHeader>
      <CardContent className="text-sm space-y-2 text-muted-foreground">
        <p>• Escrita bidirecional na planilha (com controle de conflitos last-write-wins + auditoria)</p>
        <p>• Criação de eventos no Google Calendar</p>
        <p>• Sincronização automática periódica</p>
        <p>• Alertas avançados por notificação</p>
        <p>• Correção assistida de fórmulas quebradas</p>
      </CardContent></Card></FadeIn>
    </div>
  );
}
