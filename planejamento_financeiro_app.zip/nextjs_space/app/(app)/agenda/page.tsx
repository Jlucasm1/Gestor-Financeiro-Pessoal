'use client';
import { Card, CardContent } from '@/components/ui/card';
import { PageHeader } from '@/components/layouts/page-header';
import { FadeIn } from '@/components/ui/animate';
import { Calendar, AlertTriangle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function AgendaPage() {
  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1200px] mx-auto">
      <FadeIn><PageHeader title="Agenda" description="Compromissos do Google Calendar e vencimentos financeiros." /></FadeIn>
      <FadeIn delay={0.1}><div className="flex gap-2"><Badge variant="outline" className="gap-1"><Calendar className="h-3 w-3" />Leitura do Calendar: aguardando conexão Google</Badge>
      <Badge variant="outline" className="gap-1"><AlertTriangle className="h-3 w-3" />Criação de eventos: desativada (fase 2)</Badge></div></FadeIn>
      <FadeIn><Card><CardContent className="p-8 text-center">
        <Calendar className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-semibold mb-2">Agenda não disponível</h3>
        <p className="text-muted-foreground text-sm">Conecte-se com Google SSO para visualizar compromissos do Calendar. Vencimentos financeiros aparecerão após sincronização da planilha.</p>
        <p className="text-xs text-muted-foreground mt-2">A criação de eventos no Calendar está desativada nesta versão (flag CALENDAR_WRITE_ENABLED=false).</p>
      </CardContent></Card></FadeIn>
    </div>
  );
}
