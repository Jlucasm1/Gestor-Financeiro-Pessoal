'use client';
import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { PageHeader } from '@/components/layouts/page-header';
import { FadeIn } from '@/components/ui/animate';
import { Wallet, AlertTriangle } from 'lucide-react';

export default function ContasPage() {
  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1200px] mx-auto">
      <FadeIn><PageHeader title="Contas e Finanças" description="Gestão de contas, dívidas, metas, reservas e comissões — alimentado pela planilha." /></FadeIn>
      <FadeIn><Card><CardContent className="p-8 text-center">
        <Wallet className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-semibold mb-2">Aguardando dados</h3>
        <p className="text-muted-foreground text-sm">Sincronize a planilha no Dashboard para visualizar contas, dívidas, metas e comissões. Dados serão extraídos das abas auxiliares (Plano de Comissionamento, CalculadoraDAS, etc.).</p>
      </CardContent></Card></FadeIn>
    </div>
  );
}
