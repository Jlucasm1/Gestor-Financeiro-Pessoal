'use client';
import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { PageHeader } from '@/components/layouts/page-header';
import { FadeIn } from '@/components/ui/animate';
import { SafeDate } from '@/components/safe-format';
import { Shield } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';

export default function AuditoriaPage() {
  const [logs, setLogs] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/audit').then(r => r.json()).then(d => setLogs(d?.logs ?? [])).catch(console.error).finally(() => setLoading(false));
  }, []);

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1200px] mx-auto">
      <FadeIn><PageHeader title="Auditoria" description="Registro de todas as ações: logins, sincronizações, acessos e operações." /></FadeIn>
      {loading ? <Card><CardContent className="p-6"><div className="h-32 bg-muted animate-pulse rounded" /></CardContent></Card> :
      (logs?.length ?? 0) === 0 ? (
        <FadeIn><Card><CardContent className="p-8 text-center">
          <Shield className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Nenhum registro</h3>
          <p className="text-muted-foreground text-sm">As ações serão registradas aqui conforme você utilizar o sistema.</p>
        </CardContent></Card></FadeIn>
      ) : (
        <FadeIn><Card><CardContent className="p-0">
          <Table>
            <TableHeader><TableRow>
              <TableHead className="w-[180px]">Data/Hora</TableHead>
              <TableHead>Ação</TableHead>
              <TableHead>Detalhe</TableHead>
              <TableHead className="w-[120px]">Rota</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {logs.map((log: any) => (
                <TableRow key={log?.id}>
                  <TableCell className="text-xs font-mono"><SafeDate date={log?.createdAt} options={{ dateStyle: 'short', timeStyle: 'medium' }} locale="pt-BR" /></TableCell>
                  <TableCell><Badge variant="outline" className="text-xs">{log?.action}</Badge></TableCell>
                  <TableCell className="text-sm text-muted-foreground truncate max-w-[300px]">{log?.detail ?? '—'}</TableCell>
                  <TableCell className="text-xs font-mono text-muted-foreground">{log?.route ?? '—'}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent></Card></FadeIn>
      )}
    </div>
  );
}
