'use client';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PageHeader } from '@/components/layouts/page-header';
import { FadeIn } from '@/components/ui/animate';
import { SafeDate, SafeNumber } from '@/components/safe-format';
import { CheckCircle2, AlertTriangle, FileWarning } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function ValidacaoPage() {
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/validation').then(r => r.json()).then(d => setReports(d?.reports ?? [])).catch(console.error).finally(() => setLoading(false));
  }, []);

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1200px] mx-auto">
      <FadeIn><PageHeader title="Relatório de Validação" description="Recalcula totais a partir das linhas brutas e compara com valores consolidados. Detecta fórmulas quebradas (#REF!)." /></FadeIn>
      {loading ? <Card><CardContent className="p-6"><div className="h-32 bg-muted animate-pulse rounded" /></CardContent></Card> :
      (reports?.length ?? 0) === 0 ? (
        <FadeIn><Card><CardContent className="p-8 text-center">
          <FileWarning className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Nenhuma validação realizada</h3>
          <p className="text-muted-foreground text-sm">Sincronize a planilha primeiro para gerar o relatório de validação.</p>
        </CardContent></Card></FadeIn>
      ) : (
        <div className="space-y-4">
          {reports.map((r: any) => {
            const summary = r?.summary ?? {};
            const brokenRefs = r?.brokenRefs ?? [];
            const discrepancies = r?.discrepancies ?? [];
            return (
              <FadeIn key={r?.id}>
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">Validação <SafeDate date={r?.validatedAt} options={{ dateStyle: 'medium', timeStyle: 'short' }} locale="pt-BR" /></CardTitle>
                      <Badge variant={brokenRefs.length > 0 ? 'destructive' : 'default'}>
                        {brokenRefs.length > 0 ? <><AlertTriangle className="h-3 w-3 mr-1" />{brokenRefs.length} #REF!</> : <><CheckCircle2 className="h-3 w-3 mr-1" />OK</>}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
                      <div><span className="text-muted-foreground">Abas lidas:</span> <strong>{r?.sheetsRead ?? 0}</strong></div>
                      <div><span className="text-muted-foreground">Linhas:</span> <strong>{r?.rowsProcessed ?? 0}</strong></div>
                      <div><span className="text-muted-foreground">Receitas:</span> <strong className="text-primary"><SafeNumber value={summary?.totalIncome ?? 0} currency="BRL" locale="pt-BR" /></strong></div>
                      <div><span className="text-muted-foreground">Despesas:</span> <strong className="text-destructive"><SafeNumber value={summary?.totalExpenses ?? 0} currency="BRL" locale="pt-BR" /></strong></div>
                    </div>
                    {brokenRefs.length > 0 && (
                      <div className="bg-destructive/5 rounded-lg p-3">
                        <h4 className="text-sm font-medium text-destructive flex items-center gap-1 mb-2"><AlertTriangle className="h-4 w-4" /> Fórmulas quebradas (#REF!) detectadas</h4>
                        <p className="text-xs text-muted-foreground mb-2">Encontradas {brokenRefs.length} referências quebradas. A correção deve ser feita manualmente na planilha.</p>
                        <div className="space-y-1">{brokenRefs.slice(0, 10).map((ref: any, i: number) => (
                          <p key={i} className="text-xs font-mono">Aba: {ref?.sheet} — Linha {(ref?.row ?? 0) + 1}, Coluna {String.fromCharCode(65 + (ref?.col ?? 0))}: {ref?.value}</p>
                        ))}</div>
                      </div>
                    )}
                    {discrepancies.length > 0 && (
                      <div className="bg-amber-500/5 rounded-lg p-3">
                        <h4 className="text-sm font-medium text-amber-600">Discrepâncias encontradas: {discrepancies.length}</h4>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </FadeIn>
            );
          })}
        </div>
      )}
    </div>
  );
}
