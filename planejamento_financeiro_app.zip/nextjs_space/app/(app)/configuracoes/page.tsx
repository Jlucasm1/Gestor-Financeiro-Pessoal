'use client';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PageHeader } from '@/components/layouts/page-header';
import { FadeIn } from '@/components/ui/animate';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Settings, Save, FileSpreadsheet, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { Badge } from '@/components/ui/badge';

export default function ConfiguracoesPage() {
  const [url, setUrl] = useState('');
  const [saving, setSaving] = useState(false);
  const [config, setConfig] = useState<any>(null);

  useEffect(() => {
    fetch('/api/config').then(r => r.json()).then(d => { setConfig(d?.config); setUrl(d?.config?.spreadsheetUrl ?? ''); }).catch(console.error);
  }, []);

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch('/api/config', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ spreadsheetUrl: url, configId: config?.id }) });
      if (res.ok) toast.success('Configuração salva!'); else toast.error('Erro ao salvar');
    } catch { toast.error('Erro'); } finally { setSaving(false); }
  };

  return (
    <div className="p-4 sm:p-6 space-y-6 max-w-[1200px] mx-auto">
      <FadeIn><PageHeader title="Configurações" description="Configure a planilha de origem e o mapeamento de colunas." /></FadeIn>
      <FadeIn>
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><FileSpreadsheet className="h-4 w-4" />Planilha Google Sheets</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div><Label>URL da Planilha</Label>
            <Input placeholder="https://docs.google.com/spreadsheets/d/..." value={url} onChange={e => setUrl(e.target.value)} className="mt-1" /></div>
            <p className="text-xs text-muted-foreground">Se não informado, o sistema buscará automaticamente "PLANEJAMENTO JOÃO LUCAS" no seu Drive.</p>
            <Button onClick={handleSave} disabled={saving} className="gap-2"><Save className="h-4 w-4" />Salvar</Button>
          </CardContent>
        </Card>
      </FadeIn>
      <FadeIn delay={0.1}>
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><Settings className="h-4 w-4" />Mapeamento de Colunas</CardTitle></CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">O mapeamento é detectado automaticamente a partir dos cabeçalhos da planilha (Data, Descrição, Categoria, Valor, Vencimento, Situação). Após a primeira sincronização, os mapeamentos detectados poderão ser ajustados aqui.</p>
          </CardContent>
        </Card>
      </FadeIn>
      <FadeIn delay={0.2}>
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><AlertTriangle className="h-4 w-4" />Flags de Controle</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-center gap-2"><Badge variant="outline">WRITE_ENABLED=false</Badge><span className="text-sm text-muted-foreground">Escrita na planilha desativada (modo somente leitura)</span></div>
            <div className="flex items-center gap-2"><Badge variant="outline">CALENDAR_WRITE_ENABLED=false</Badge><span className="text-sm text-muted-foreground">Criação de eventos no Calendar desativada</span></div>
          </CardContent>
        </Card>
      </FadeIn>
    </div>
  );
}
