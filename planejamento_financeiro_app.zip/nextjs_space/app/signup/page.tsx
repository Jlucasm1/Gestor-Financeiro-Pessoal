'use client';
import { useState } from 'react';
import { signIn } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { AuthLayout } from '@/components/layouts/auth-layout';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import Link from 'next/link';

export default function SignupPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true); setError('');
    try {
      const res = await fetch('/api/signup', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password, name }) });
      const data = await res.json();
      if (!res.ok) { setError(data?.error ?? 'Erro'); return; }
      const login = await signIn('credentials', { email, password, redirect: false });
      if (login?.error) setError('Conta criada, faça login manualmente');
      else router.replace('/dashboard');
    } catch { setError('Erro ao cadastrar'); } finally { setLoading(false); }
  };

  return (
    <AuthLayout title="Criar Conta" description="Cadastre-se para acessar a gestão financeira">
      <form onSubmit={handleSubmit} className="space-y-3">
        <div><Label>Nome</Label><Input value={name} onChange={e => setName(e.target.value)} className="mt-1" /></div>
        <div><Label>Email</Label><Input type="email" value={email} onChange={e => setEmail(e.target.value)} required className="mt-1" /></div>
        <div><Label>Senha</Label><Input type="password" value={password} onChange={e => setPassword(e.target.value)} required minLength={6} className="mt-1" /></div>
        {error && <p className="text-sm text-destructive">{error}</p>}
        <Button type="submit" className="w-full" disabled={loading}>{loading ? 'Criando...' : 'Criar conta'}</Button>
      </form>
      <p className="text-center text-sm text-muted-foreground mt-4">Já tem conta? <Link href="/login" className="text-primary hover:underline">Entrar</Link></p>
    </AuthLayout>
  );
}
