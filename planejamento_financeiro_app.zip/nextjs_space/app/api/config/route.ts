export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  const config = await prisma.spreadsheetConfig.findFirst({
    where: { userId: session.user.id, isActive: true },
  });
  const mappings = await prisma.columnMapping.findMany({
    where: { userId: session.user.id },
  });

  return NextResponse.json({ config, mappings });
}

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  const body = await req.json();

  if (body?.spreadsheetUrl) {
    // Extract spreadsheet ID from URL
    const match = body.spreadsheetUrl.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
    const spreadsheetId = match?.[1] ?? null;

    await prisma.spreadsheetConfig.upsert({
      where: { id: body?.configId ?? 'new' },
      create: {
        userId: session.user.id,
        spreadsheetUrl: body.spreadsheetUrl,
        spreadsheetId,
      },
      update: {
        spreadsheetUrl: body.spreadsheetUrl,
        spreadsheetId,
      },
    });
  }

  if (body?.sheetName && body?.mappings) {
    await prisma.columnMapping.upsert({
      where: { userId_sheetName: { userId: session.user.id, sheetName: body.sheetName } },
      create: {
        userId: session.user.id,
        sheetName: body.sheetName,
        mappings: body.mappings,
      },
      update: { mappings: body.mappings },
    });
  }

  return NextResponse.json({ success: true });
}
