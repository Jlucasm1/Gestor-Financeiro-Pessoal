export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/prisma';

export async function GET() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  try {
    const lastSnapshot = await prisma.syncSnapshot.findFirst({
      where: { userId: session.user.id },
      orderBy: { syncedAt: 'desc' },
    });

    const lastValidation = await prisma.validationReport.findFirst({
      where: { userId: session.user.id },
      orderBy: { validatedAt: 'desc' },
    });

    // Check if user has Google account linked (for integration status)
    const googleAccount = await prisma.account.findFirst({
      where: { userId: session.user.id, provider: 'google' },
    });

    const hasGoogleToken = googleAccount?.access_token != null;

    const summary = (lastValidation?.summary as any) ?? {};
    const snapshotData = (lastSnapshot?.data as any) ?? {};

    return NextResponse.json({
      totalIncome: summary?.totalIncome ?? 0,
      totalExpenses: summary?.totalExpenses ?? 0,
      balance: summary?.calculatedBalance ?? 0,
      paidCount: summary?.paidCount ?? 0,
      pendingCount: summary?.pendingCount ?? 0,
      sheetsRead: lastSnapshot?.sheetsRead ?? 0,
      rowsProcessed: lastSnapshot?.rowsProcessed ?? 0,
      lastSync: lastSnapshot?.syncedAt?.toISOString() ?? null,
      monthlyData: [],
      integrationStatus: {
        sheets: {
          connected: hasGoogleToken,
          lastSync: lastSnapshot?.syncedAt?.toISOString() ?? null,
          error: null,
        },
        calendar: {
          connected: hasGoogleToken,
          lastSync: null,
          error: null,
        },
      },
    });
  } catch (err: any) {
    console.error('Dashboard error:', err);
    return NextResponse.json({ error: 'Erro interno' }, { status: 500 });
  }
}
