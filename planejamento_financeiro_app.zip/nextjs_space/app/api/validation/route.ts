export const dynamic = 'force-dynamic';
import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  const url = new URL(req.url);
  const limit = Math.min(parseInt(url.searchParams.get('limit') ?? '20'), 50);

  const reports = await prisma.validationReport.findMany({
    where: { userId: session.user.id },
    orderBy: { validatedAt: 'desc' },
    take: limit,
  });

  return NextResponse.json({
    reports: reports.map((r: any) => ({
      ...r,
      validatedAt: r.validatedAt?.toISOString(),
    })),
  });
}
