export const dynamic = 'force-dynamic';
import { NextResponse } from 'next/server';
import { auth } from '@/auth';
import { prisma } from '@/lib/prisma';
import { classifySheet, detectColumnMapping, detectBrokenRefs } from '@/lib/sheets-helpers';
import { validateSheetData } from '@/lib/validation';
import { logAudit } from '@/lib/audit';

async function getGoogleAccessToken(userId: string): Promise<string | null> {
  const account = await prisma.account.findFirst({
    where: { userId, provider: 'google' },
  });
  return account?.access_token ?? null;
}

async function findSpreadsheet(accessToken: string, userId: string): Promise<{ id: string; name: string } | null> {
  // Check if user has a fixed spreadsheet configured
  const config = await prisma.spreadsheetConfig.findFirst({
    where: { userId, isActive: true },
  });
  if (config?.spreadsheetId) {
    return { id: config.spreadsheetId, name: 'Configurada' };
  }

  // Search in Drive for the spreadsheet
  try {
    const query = encodeURIComponent("name = 'PLANEJAMENTO JOÃO LUCAS' and mimeType = 'application/vnd.google-apps.spreadsheet'");
    const res = await fetch(
      `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name)`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );
    if (!res.ok) return null;
    const data = await res.json();
    const files = data?.files ?? [];
    if (files.length > 0) return { id: files[0].id, name: files[0].name };
  } catch (err: any) {
    console.error('Drive search error:', err);
  }
  return null;
}

async function readAllSheets(accessToken: string, spreadsheetId: string) {
  // Get spreadsheet metadata (sheet names)
  const metaRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=sheets.properties`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  if (!metaRes.ok) throw new Error(`Sheets API error: ${metaRes.status}`);
  const meta = await metaRes.json();
  const sheets = (meta?.sheets ?? []).map((s: any) => s?.properties?.title).filter(Boolean);

  const result: Record<string, any[][]> = {};
  for (const sheetName of sheets) {
    try {
      const range = encodeURIComponent(`'${sheetName}'`);
      const dataRes = await fetch(
        `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}`,
        { headers: { Authorization: `Bearer ${accessToken}` } }
      );
      if (dataRes.ok) {
        const d = await dataRes.json();
        result[sheetName] = d?.values ?? [];
      }
    } catch (err: any) {
      console.error(`Error reading sheet ${sheetName}:`, err);
    }
  }
  return { sheets, data: result };
}

export async function POST() {
  const session = await auth();
  if (!session?.user?.id) return NextResponse.json({ error: 'Não autorizado' }, { status: 401 });

  try {
    const accessToken = await getGoogleAccessToken(session.user.id);
    if (!accessToken) {
      return NextResponse.json({
        error: 'Token Google não disponível. Faça login com Google para sincronizar.',
        needsGoogleAuth: true,
      }, { status: 403 });
    }

    const spreadsheet = await findSpreadsheet(accessToken, session.user.id);
    if (!spreadsheet) {
      return NextResponse.json({
        error: 'Planilha "PLANEJAMENTO JOÃO LUCAS" não encontrada. Verifique se ela existe no seu Google Drive ou configure o link em Configurações.',
        notFound: true,
      }, { status: 404 });
    }

    const { sheets, data } = await readAllSheets(accessToken, spreadsheet.id);

    // Auto-detect column mappings
    const columnMappings: Record<string, Record<string, number>> = {};
    let totalRows = 0;
    for (const sheetName of sheets) {
      const rows = data[sheetName] ?? [];
      totalRows += Math.max(0, (rows?.length ?? 0) - 1);
      if ((rows?.length ?? 0) > 0) {
        const headers = rows[0] ?? [];
        // Check if user has custom mapping
        const custom = await prisma.columnMapping.findUnique({
          where: { userId_sheetName: { userId: session.user.id, sheetName } },
        });
        columnMappings[sheetName] = custom ? (custom.mappings as Record<string, number>) : detectColumnMapping(headers);
      }
    }

    // Validate
    const validation = validateSheetData(data, columnMappings);

    // Save snapshot
    const snapshot = await prisma.syncSnapshot.create({
      data: {
        userId: session.user.id,
        spreadsheetId: spreadsheet.id,
        sheetsRead: sheets?.length ?? 0,
        rowsProcessed: totalRows,
        data: data as any,
        changeLog: null,
      },
    });

    // Save validation report
    await prisma.validationReport.create({
      data: {
        userId: session.user.id,
        sheetsRead: sheets?.length ?? 0,
        rowsProcessed: totalRows,
        discrepancies: validation.discrepancies as any,
        brokenRefs: validation.brokenRefs as any,
        summary: {
          totalIncome: validation.totalIncome,
          totalExpenses: validation.totalExpenses,
          calculatedBalance: validation.calculatedBalance,
          paidCount: validation.paidCount,
          pendingCount: validation.pendingCount,
        } as any,
      },
    });

    await logAudit('sync', `Sincronizou ${sheets?.length ?? 0} abas, ${totalRows} linhas da planilha ${spreadsheet.id}`, '/api/sheets/sync');

    return NextResponse.json({
      success: true,
      sheetsRead: sheets?.length ?? 0,
      rowsProcessed: totalRows,
      sheetNames: sheets,
      sheetClassifications: sheets.map((s: string) => ({ name: s, type: classifySheet(s) })),
      brokenRefs: validation.brokenRefs?.length ?? 0,
      snapshotId: snapshot.id,
    });
  } catch (err: any) {
    console.error('Sync error:', err);
    await logAudit('sync_error', err?.message ?? 'Erro desconhecido', '/api/sheets/sync');
    return NextResponse.json({ error: 'Erro na sincronização: ' + (err?.message ?? '') }, { status: 500 });
  }
}
