import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  // Hidden test account
  const hashedPassword = await bcrypt.hash('Y3VTaZ*N0E', 12);
  await prisma.user.upsert({
    where: { email: 'abacus-7eea612d@example.com' },
    update: {},
    create: {
      email: 'abacus-7eea612d@example.com',
      name: 'Test Admin',
      password: hashedPassword,
      role: 'admin',
    },
  });

  console.log('Seed completed.');
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
