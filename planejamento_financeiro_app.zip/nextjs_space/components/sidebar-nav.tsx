'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { signOut, useSession } from 'next-auth/react';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard, FileSpreadsheet, CheckCircle2, Calendar,
  Settings, Shield, BookOpen, RefreshCw, LogOut, Wallet, AlertTriangle
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const NAV_ITEMS = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/contas', label: 'Contas e Finanças', icon: Wallet },
  { href: '/validacao', label: 'Validação', icon: CheckCircle2 },
  { href: '/agenda', label: 'Agenda', icon: Calendar },
  { href: '/auditoria', label: 'Auditoria', icon: Shield },
  { href: '/configuracoes', label: 'Configurações', icon: Settings },
  { href: '/sobre', label: 'Sobre', icon: BookOpen },
];

export function SidebarNav() {
  const pathname = usePathname();
  const { data: session } = useSession();

  return (
    <div className="flex flex-col h-full">
      <div className="mb-6">
        <h2 className="font-display text-lg font-bold tracking-tight text-primary">Gestão Financeira</h2>
        <p className="text-xs text-muted-foreground mt-1">Planejamento João Lucas</p>
      </div>
      <nav className="flex-1 space-y-1">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = pathname?.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors',
                active
                  ? 'bg-primary/10 text-primary font-medium'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
              )}
            >
              <Icon className="h-4 w-4 flex-shrink-0" />
              {item.label}
            </Link>
          );
        })}
      </nav>
      <div className="mt-auto pt-4 border-t">
        <div className="px-3 py-2">
          <p className="text-xs text-muted-foreground truncate">{session?.user?.email ?? ''}</p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="w-full justify-start gap-2 text-muted-foreground"
          onClick={() => signOut({ redirectTo: '/login' })}
        >
          <LogOut className="h-4 w-4" /> Sair
        </Button>
      </div>
    </div>
  );
}
