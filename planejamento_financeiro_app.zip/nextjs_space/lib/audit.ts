import { prisma } from '@/lib/prisma';
import { auth } from '@/auth';

export async function logAudit(action: string, detail?: string, route?: string) {
  try {
    const session = await auth();
    await prisma.auditLog.create({
      data: {
        userId: session?.user?.id ?? null,
        userEmail: session?.user?.email ?? null,
        action,
        detail: detail ?? null,
        route: route ?? null,
      },
    });
  } catch (err: any) {
    console.error('Audit log error:', err?.message);
  }
}
