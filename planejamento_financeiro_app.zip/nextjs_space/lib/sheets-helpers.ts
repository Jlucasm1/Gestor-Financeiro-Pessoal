// Helpers for Google Sheets integration — READ-ONLY mode

const WRITE_ENABLED = process.env.WRITE_ENABLED === 'true';

// Month name patterns to detect monthly tabs
const MONTH_PATTERNS = [
  /^jan(eiro)?$/i, /^fev(ereiro)?$/i, /^mar(ço|co)?$/i, /^abr(il)?$/i,
  /^mai(o)?$/i, /^jun(ho)?$/i, /^jul(ho)?$/i, /^ago(sto)?$/i,
  /^set(embro)?$/i, /^out(ubro)?$/i, /^nov(embro)?$/i, /^dez(embro)?$/i,
];

const AUXILIARY_SHEETS = [
  'plano de comissionamento',
  'calculadoradas',
  'tabela anexo iii',
  'histórico de cálculos',
  'historico de calculos',
];

export function classifySheet(name: string): 'monthly' | 'auxiliary' | 'unknown' {
  const lower = (name ?? '').trim().toLowerCase();
  // Check if it matches a month pattern (possibly with year, e.g. "JAN 2024")
  const cleanName = lower.replace(/\s*\d{2,4}\s*$/, '').trim();
  for (const pattern of MONTH_PATTERNS) {
    if (pattern.test(cleanName)) return 'monthly';
  }
  if (AUXILIARY_SHEETS.some((a: string) => lower.includes(a))) return 'auxiliary';
  return 'unknown';
}

export function getMonthIndex(name: string): number {
  const lower = (name ?? '').trim().toLowerCase().replace(/\s*\d{2,4}\s*$/, '').trim();
  for (let i = 0; i < MONTH_PATTERNS.length; i++) {
    if (MONTH_PATTERNS[i]?.test(lower)) return i;
  }
  return -1;
}

// Heuristic column mapping from header row
const HEADER_MAP: Record<string, string[]> = {
  date: ['data', 'dt', 'date', 'dia'],
  description: ['descrição', 'descricao', 'desc', 'description', 'histórico', 'historico'],
  category: ['categoria', 'cat', 'category', 'tipo'],
  value: ['valor', 'value', 'vlr', 'montante', 'quantia'],
  dueDate: ['vencimento', 'venc', 'due', 'dt vencimento', 'data vencimento'],
  status: ['situação', 'situacao', 'status', 'pago', 'pago?', 'pg', 'sit'],
};

export function detectColumnMapping(headers: string[]): Record<string, number> {
  const mapping: Record<string, number> = {};
  const normalizedHeaders = (headers ?? []).map((h: string) => (h ?? '').toString().toLowerCase().trim());
  for (const [field, aliases] of Object.entries(HEADER_MAP)) {
    for (let i = 0; i < normalizedHeaders.length; i++) {
      if ((aliases ?? []).some((a: string) => normalizedHeaders[i]?.includes(a))) {
        mapping[field] = i;
        break;
      }
    }
  }
  return mapping;
}

export function isWriteEnabled(): boolean {
  return WRITE_ENABLED;
}

// Parse Brazilian currency "R$ 1.234,56" → number
export function parseBRL(value: string | number | null | undefined): number {
  if (value == null) return 0;
  if (typeof value === 'number') return value;
  const cleaned = value.toString()
    .replace(/R\$\s*/g, '')
    .replace(/\./g, '')
    .replace(',', '.')
    .replace(/[^\d.-]/g, '')
    .trim();
  const num = parseFloat(cleaned);
  return isNaN(num) ? 0 : num;
}

// Detect broken references (#REF!)
export function detectBrokenRefs(rows: any[][]): { row: number; col: number; value: string }[] {
  const broken: { row: number; col: number; value: string }[] = [];
  for (let r = 0; r < (rows?.length ?? 0); r++) {
    const row = rows?.[r] ?? [];
    for (let c = 0; c < (row?.length ?? 0); c++) {
      const cell = row?.[c];
      if (cell != null && cell.toString().includes('#REF!')) {
        broken.push({ row: r, col: c, value: cell.toString() });
      }
    }
  }
  return broken;
}
