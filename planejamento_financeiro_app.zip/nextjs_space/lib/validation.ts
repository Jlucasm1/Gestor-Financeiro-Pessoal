// Validation module — recalculates totals from raw rows and compares with sheet totals

import { parseBRL } from './sheets-helpers';

export interface Discrepancy {
  sheet: string;
  field: string;
  expected: number;
  actual: number;
  diff: number;
  severity: 'low' | 'medium' | 'high';
}

export interface ValidationResult {
  sheetsRead: number;
  rowsProcessed: number;
  discrepancies: Discrepancy[];
  brokenRefs: { sheet: string; row: number; col: number; value: string }[];
  totalIncome: number;
  totalExpenses: number;
  calculatedBalance: number;
  paidCount: number;
  pendingCount: number;
}

export function validateSheetData(
  sheetsData: Record<string, any[][]>,
  columnMappings: Record<string, Record<string, number>>
): ValidationResult {
  let totalIncome = 0;
  let totalExpenses = 0;
  let rowsProcessed = 0;
  let paidCount = 0;
  let pendingCount = 0;
  const discrepancies: Discrepancy[] = [];
  const brokenRefs: { sheet: string; row: number; col: number; value: string }[] = [];

  const sheetNames = Object.keys(sheetsData ?? {});

  for (const sheetName of sheetNames) {
    const rows = sheetsData?.[sheetName] ?? [];
    const mapping = columnMappings?.[sheetName] ?? {};
    const valueCol = mapping?.value;
    const statusCol = mapping?.status;

    // Detect broken references
    for (let r = 0; r < (rows?.length ?? 0); r++) {
      const row = rows?.[r] ?? [];
      for (let c = 0; c < (row?.length ?? 0); c++) {
        const cell = row?.[c];
        if (cell != null && cell?.toString?.()?.includes?.('#REF!')) {
          brokenRefs.push({ sheet: sheetName, row: r, col: c, value: cell?.toString?.() ?? '' });
        }
      }
    }

    if (valueCol == null) continue;

    // Skip header row (index 0)
    for (let r = 1; r < (rows?.length ?? 0); r++) {
      const row = rows?.[r] ?? [];
      if (!row || (row?.length ?? 0) === 0) continue;
      const val = parseBRL(row?.[valueCol]);
      if (val === 0) continue;
      rowsProcessed++;

      if (val > 0) totalIncome += val;
      else totalExpenses += Math.abs(val);

      if (statusCol != null) {
        const status = (row?.[statusCol] ?? '').toString().toLowerCase().trim();
        if (['pago', 'sim', 'yes', 'ok', 'x', 'true', '1'].includes(status)) {
          paidCount++;
        } else if (status && !['', '-'].includes(status)) {
          pendingCount++;
        }
      }
    }
  }

  return {
    sheetsRead: sheetNames?.length ?? 0,
    rowsProcessed,
    discrepancies,
    brokenRefs,
    totalIncome,
    totalExpenses,
    calculatedBalance: totalIncome - totalExpenses,
    paidCount,
    pendingCount,
  };
}
